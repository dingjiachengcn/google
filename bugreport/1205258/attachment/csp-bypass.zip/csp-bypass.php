<?php
 header("Content-Security-Policy: default-src 'self'");
?>

<!DOCTYPE html>
<html>
  <head>
    <script src="csp-bypass.js"></script> <!-- trusted -->
    <script>alert('script inline on page');</script> <!-- blocked, OK -->
  </head>
  <body>
    <div id="bar"></div>
    <img src="onPage.jpg" onerror="alert('img on page')"/> <!-- blocked, OK -->
    <script src="https://foo.example/onPage.js"></script> <!-- blocked, OK -->
  </body>
</html>
