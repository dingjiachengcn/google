function addElem(el, url, innerHTML) {
  var s = document.createElement(el);
  if (url !== null ) { s.src = url; };
  if (innerHTML !== null ) { s.innerHTML = innerHTML; };
  document.body.appendChild(s);
  return s;
}

window.onload = function() {
  document.getElementById('bar').innerHTML += "<img src='innerHTML.jpg' onerror='alert(\"img by innerHTML\")'/>"; // blocked, OK
  addElem('script', 'https://foo.example/createElement.js'); // blocked, OK
  addElem('script', null, 'alert("script by createElement")'); // blocked, OK
  addElem('img', 'createElement.jpg').onerror = function () {
    alert('img by createElement'); }; // NOT BLOCKED
}
