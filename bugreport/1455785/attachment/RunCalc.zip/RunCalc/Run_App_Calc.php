<?php
$os = strtoupper(substr(PHP_OS, 0, 3));

if ($os === 'WIN') {
    exec('calc.exe');
    echo 'App Calculator Run';
} else {
    echo 'App Calculator only open in Windows OS';
}
?>
