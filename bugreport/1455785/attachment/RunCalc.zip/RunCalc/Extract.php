<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $directoryToZip = $_POST['directory'];

    $zipFileName = 'NameFile.zip';

    $zip = zip_open($zipFileName);

    if ($zip) {
        while ($zip_entry = zip_read($zip)) {
            $entryName = zip_entry_name($zip_entry);
            $entryPath = $directoryToZip . '/' . $entryName;

            if (zip_entry_open($zip, $zip_entry, "r")) {
                if (is_dir($entryPath)) {
                    mkdir($entryPath, 0777, true);
                } else {
                    $file = fopen($entryPath, "w");
                    fwrite($file, zip_entry_read($zip_entry, zip_entry_filesize($zip_entry)));
                    fclose($file);
                }
                zip_entry_close($zip_entry);
            }
        }

        zip_close($zip);
        echo "Extract Complete";
    } else {
        echo "Failed to open zip file.";
    }
}
?>
