// var app = chrome.runtime.getBackgroundPage();

function onClickCrashRemote() {
    chrome.extension.getBackgroundPage().go(true);
}

document.getElementById('crashremotebutton').addEventListener('click', onClickCrashRemote);