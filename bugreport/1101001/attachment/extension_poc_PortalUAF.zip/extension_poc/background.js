var fuzzFileRemoteLocation = "http://localhost:8081/";
var fileName = "TryMe.html";
var filePath = "";

function go(remote) {
	//Note: Local doesn't work for portals
    filePath = remote ? fuzzFileRemoteLocation + fileName : fileName;
    openNewTab(filePath);
}

function openNewTab( filepath ) {
    chrome.tabs.create({"url": filepath, "active": true}, function(tab) {
    });
}