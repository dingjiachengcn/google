#! /usr/bin/python

import os
import shutil
import sys

base_path = sys.argv[1]
target = sys.argv[2]
paths = []
for path, dirs, files in os.walk(base_path):
  for file in files:
    if file == 'mojo_bindings.js':
      shutil.copyfile(os.path.join(path, file), os.path.join(target, file))

    if file == 'bindings_lite.js':
      shutil.copyfile(os.path.join(path, file), os.path.join(target, file))

    if file == 'mojo_bindings_lite.js':
      shutil.copyfile(os.path.join(path, file), os.path.join(target, file))
    
    if file.endswith('.mojom.js') or file.endswith('.mojom-lite.js'):
      target_path = os.path.join(target, path[len(base_path) + 1:])
      try:
        os.makedirs(target_path)
      except:
        pass
      shutil.copyfile(os.path.join(path, file), os.path.join(target_path, file))
        
      abs_path = os.path.join(target_path, file)
      final_path = abs_path[abs_path.find("gen") - 1:]
      paths.append("<script src=\"" + final_path + "\"></script>")
