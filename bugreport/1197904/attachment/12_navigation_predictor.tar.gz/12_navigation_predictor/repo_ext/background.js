chrome.tabs.create({url:chrome.extension.getURL("js/main.html")}, function(tab) {
	targetId = tab.id;
	console.log('[background.js] chrome.tabs.create',tab)
});
