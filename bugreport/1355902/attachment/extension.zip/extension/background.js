
var atabid;
chrome.windows.create({ url: "data:application/pdf;base64,JVBERi0xLjcKJaDypPQKMSAwIG9iaiA8PAogIC9UeXBlIC9DYXRhbG9nCiAgL1BhZ2VzIDIgMCBSCj4+CmVuZG9iagoyIDAgb2JqIDw8CiAgL1R5cGUgL1BhZ2VzCiAgL01lZGlhQm94IFsgMCAwIDIwMCAzMDAgXQogIC9Db3VudCAxCiAgL0tpZHMgWyAzIDAgUiBdCj4+CmVuZG9iagozIDAgb2JqIDw8CiAgL1R5cGUgL1BhZ2UKICAvUGFyZW50IDIgMCBSCiAgL0NvbnRlbnRzIDQgMCBSCj4+CmVuZG9iago0IDAgb2JqIDw8Cj4+CnN0cmVhbQpxCjAgMCAwIHJnCjAgMjkwIDEwIDEwIHJlIEIqCjEwIDE1MCA1MCAzMCByZSBCKgowIDAgMSByZwoxOTAgMjkwIDEwIDEwIHJlIEIqCjcwIDIzMiA1MCAzMCByZSBCKgowIDEgMCByZwoxOTAgMCAxMCAxMCByZSBCKgoxMzAgMTUwIDUwIDMwIHJlIEIqCjEgMCAwIHJnCjAgMCAxMCAxMCByZSBCKgo3MCA2NyA1MCAzMCByZSBCKgpRCmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDUKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDAwNjggMDAwMDAgbiAKMDAwMDAwMDE2MSAwMDAwMCBuIAowMDAwMDAwMjMwIDAwMDAwIG4gCnRyYWlsZXI8PCAvUm9vdCAxIDAgUiAvU2l6ZSA1ID4+CnN0YXJ0eHJlZgo0NTYKJSVFT0YK", type: "normal" }, (w) => {
  atabid = w.tabs[0].id;
  debuggee = { tabId: atabid };
  chrome.debugger.attach(debuggee, "1.3", function () {

    setInterval((g) => {
      chrome.debugger.sendCommand(debuggee, "Tracing.end", {}, cc => { console.log("Tracing.end"); console.log(cc) })
      chrome.debugger.sendCommand(debuggee, "Tracing.start", { 'bufferUsageReportingInterval': 0.1, 'transferMode': 'ReportEvents', 'traceConfig': { 'recordMode': 'recordContinuously', 'traceBufferSizeInKb': 1, 'enableSampling': true, 'enableSystrace': true, 'enableArgumentFilter': false, 'includedCategories': ["ok"], 'excludedCategories': ["dd"], 'syntheticDelays': ["oss"], 'memoryDumpConfig': {} } }, cc => { console.log("Tracing.start"); console.log(cc) })

    }, 60);
  });
});


// http://localhost:3333/winclose.html