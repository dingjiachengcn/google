chrome.fileSystem.chooseEntry({type: 'openDirectory'},
function(readOnlyEntry) {
  });
setTimeout(() => {
  window.close()
}, 3000);
