<?php
/**
 * Websocket Development File
 * 
 * @package FormsFramework
 * @subpackage common
 * @author Samuele Diella <samuele.diella@gmail.com>
 * @copyright Copyright (c) 2004-2021, Samuele Diella
 * @license https://opensource.org/licenses/LGPL-3.0
 * @link https://www.ffphp.com
 */

namespace FF\Libs\PWA\WebSocket;

abstract class Server_base
{
	static $instance		= null;
	
	public $addr			= "127.0.0.1";
	public $port			= 9000;
	public $allowed_hosts	= [];
	public $allowed_origins	= [];
	
	public $ssl				= false;
	public $ssl_options		= []; // see https://www.php.net/manual/en/context.ssl.php

	protected $sock		= null;
	protected $sock_id	= null;
	
	protected $clients	= [];
	protected $sockets	= []; // include the server' one
	
	const ERR_SEND_WRONG_HANDLER		= 1;
	const ERR_SEND_SOCKET			= 2;
	
	static function getInstance(): Server_base
	{
		if (self::$instance === null)
		{
			self::$instance = new static();
		}
		
		return self::$instance;
	}
	
	protected function __construct()
	{
	}
	
	public function start($client_class)
	{
		echo "Forms Framework PHP WebSocket Daemon v" . VERSION . "\n\n";

		if ($this->ssl)
		{
			DebugOutput("Create a streaming socket of type TCP/IP over SSL on address " . $this->addr . ":" . $this->port . ".. ", 0, false);
			$context = stream_context_create([
				"ssl" => $this->ssl_options
			]);
			if (!is_resource($context))
			{
				DebugError(-1, "Unable to create the stream context");
				throw new Exception("Unable to create the stream context");
			}
			
			$this->sock = stream_socket_server(
					"ssl://" . $this->addr . ":" . $this->port, 
					$errno, 
					$errstr,
					STREAM_SERVER_BIND | STREAM_SERVER_LISTEN,
					$context
				);
		}
		else
		{
			DebugOutput("Create a streaming socket of type TCP/IP on address " . $this->addr . ":" . $this->port . ".. ", 0, false);
			$this->sock = stream_socket_server(
					"tcp://" . $this->addr . ":" . $this->port, 
					$errno, 
					$errstr,
					STREAM_SERVER_BIND | STREAM_SERVER_LISTEN
				);
		}
		
		if (!$this->sock)
		{
			DebugError($errno, $errstr);
			throw new Exception("Unable to create server socket");
		}
		stream_set_blocking($this->sock, true);
		$this->sock_id = get_resource_id($this->sock);

		DebugOutput("Done");
		
		// create a list of all the clients that will be connected to us..
		// add the listening socket to this list
		$this->clients = [];
		$this->sockets = [
			$this->sock_id => $this->sock
		];

		while (true)
		{
			// create a copy, so $this->clients doesn't get modified by socket_select()
			$read = $this->sockets;
			$write = null;
			$except = null;
			
			// get a list of all the clients that have data to be read from
			// if there are no clients with data, go to next iteration
			$rc = @stream_select($read, $write, $except, 0);
			if ($rc === 0)
			{
				continue;
			}
			if ($rc === false)
			{
				DebugError(-1, "Unknown");
				throw new Exception("Stream select error");
			}
			
			// check if there is a client trying to connect
			while (isset($read[$this->sock_id])) // while used for error management with break
			{
				// remove the listening socket from the clients-with-data array to avoid iteration in the next cycle
				unset($read[$this->sock_id]);
				
				DebugOutput("Accepting new connection.. ", 0, false);

				$newsock = @stream_socket_accept($this->sock);
				if ($newsock === false)
				{
					if (DEBUG) DebugError(-1, "unable to accept");
					break;
				}

				@stream_set_blocking($this->sock, true);
				
				DebugOutput("Done");
				
				/* all good, create the client */
				
				$tmp_id = get_resource_id($newsock);
				$this->sockets[$tmp_id] = $newsock;

				$newclient = new $client_class($tmp_id, $newsock, $this);
				$this->clients[$tmp_id] = $newclient;
				
				DebugOutput("New client connected #" . $newclient->getID() . "[" . $newclient->getIP() . "]", 1);

				break;
			}
			
			// loop through all the clients that have data to read from
			foreach ($read as $client_id => $read_sock)
			{
				if (empty($client = $this->clients[$client_id]))
				{
					DebugOutput("ERROR: got data from unknown client");
					continue;
				}

				$raw_data = fread($read_sock, 4096);
				$bytes = strlen($raw_data);

				// check if the client is disconnected
				if ($raw_data === false)
				{
					DebugOutput("Error on fread, disconnecting", 1);
					
					$client->disconnect();

					// continue to the next client to read from, if any
					continue;
				}

				if (!$bytes)
				{
					break;
				}

				DebugOutput("Data Received - client #" . $client_id . "[". $client->getIP() . "] - " . $bytes . " bytes");
				
				$rc = $client->receive($raw_data, $bytes);
				
				if ($rc === false) // error
				{
				}
				else if ($rc === null) // ignore
				{
				}
				else if ($rc === true) // got something
				{
				}
			} // end of reading foreach
		}

		// close the listening socket
		$this->stop();
	}
	
	public function removeClient($client_id)
	{
		unset($this->clients[$client_id]);
		unset($this->sockets[$client_id]);
	}
	
	/*
	 * $exclude must be a list of clients id (socket resource id)
	 */
	public function sendToAll($data, $exclude = [])
	{
		$tmp = array_keys($this->clients);
		$tmp = array_diff($tmp, $exclude);
		return $this->sendTo($tmp);
	}

	public function sendTo($clients = [], $data)
	{
		$errors = [];
		
		foreach ($clients as $client)
		{
			if (is_string($client) || is_int($client))
			{
				$this->clients[$client]->send($data);
			}
			else if (is_subclass_of($client, "FF\Libs\PWA\WebSocket\Client_base"))
			{
				$rc = $client->send($data);
				if ($rc !== false)
				{
					$errors[] = [
						"code"	=> self::ERR_SEND_SOCKET,
						"descr"	=> "socket error",
						"data"	=> $rc
					];
				}
			}
			else
			{
				$errors[] = [
					"code"	=> self::ERR_SEND_WRONG_HANDLER,
					"descr"	=> "Unhandled client handler: " . var_export($client, true)
				];
			}
		}
		
		if (count($errors))
			return false;
		else
			return $errors;
	}

	public function stop()
	{
		if ($this->sock !== null)
			return;
		
		foreach ($this->clients as $client)
		{
			$client->disconnect();
		}

		@socket_close($this->sock);
		$this->sock = null;
	}

	public function __destruct()
	{
		$this->stop();
	}
}
