<?php
/**
 * Websocket Development File
 * 
 * @package FormsFramework
 * @subpackage common
 * @author Samuele Diella <samuele.diella@gmail.com>
 * @copyright Copyright (c) 2004-2021, Samuele Diella
 * @license https://opensource.org/licenses/LGPL-3.0
 * @link https://www.ffphp.com
 */

use FF\Libs\PWA\WebSocket;

require "constants.php";

require "Server_base.php";
require "Client_base.php";

require "helpers.php";

class myServer extends WebSocket\Server_base 
{
}

class myClient extends WebSocket\Client_base
{
	public function onClose($code, $text) {
	}
	
	public function onError($code, $text) {
	}
	
	public function onMessage($type, $payload) {
	}
	
	public function onOpen() {
		return $this->sendMessage(self::PROT_OPCODE_TEXT, false, "Hello!");
	}
}

$server = myServer::getInstance();
$server->addr = "0.0.0.0";
$server->port = "9000";
$server->allowed_hosts = [
		"ffphp.sam:9000",
		"ffphp.sam",
		"localhost:9000",
		"localhost",
	];
$server->allowed_origins = [
		"http://localhost",
		"https://localhost",
		"http://ffphp.sam",
		"https://ffphp.sam",
		"http://www.ffphp.sam",
		"https://www.ffphp.sam",
	];
/*$server->ssl = true;
$server->ssl_options = [
	'cafile'			=> __DIR__ . "/certs/myCA.pem",
	'local_cert'		=> __DIR__ . "/certs/ffphp.sam.crt",
	'local_pk'			=> __DIR__ . "/certs/ffphp.sam.key",
	'allow_self_signed' => true,
	'verify_peer'		=> false,
];*/

$server->start(myClient::class);
