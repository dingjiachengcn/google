<?php
/**
 * Websocket Development File
 * 
 * @package FormsFramework
 * @subpackage common
 * @author Samuele Diella <samuele.diella@gmail.com>
 * @copyright Copyright (c) 2004-2021, Samuele Diella
 * @license https://opensource.org/licenses/LGPL-3.0
 * @link https://www.ffphp.com
 */

namespace FF\Libs\PWA\WebSocket;

function DebugOutput($text, $level = 0, $newline = true, $force_view = false)
{
	if (!$force_view && !DEBUG)
		return;
	
	static $last_indent = 0;
	static $last_newline = 1;
	
	if ($last_newline)
	{
		$date = \DateTime::createFromFormat('U.u', microtime(TRUE));
		echo $date->format('Y-m-d H:i:s.u') . " ";
		
		$indent = "";
		if ($level === null)
		{
			$indent = $last_indent;
		}
		else
		{
			for ($i = 0; $i < $level; $i++) {
				$indent .= "\t";
			}
			$last_indent = $indent;
		}
		
		echo $indent;
	}
	
	echo $text . ($newline ? "\n" : "");
	
	$last_newline = $newline;
}

function DebugError($code, $string, $level = null)
{
	DebugOutput("ERROR: (" . $code . ") " . $string, $level);
}

if (!function_exists("get_resource_id"))
{
	function get_resource_id($res)
	{
		if (!is_resource($res))
			return false;
		
		$tmp = strtolower("" . $res);
		if (strpos($tmp, "resource id #") !== 0)
			return false;
		
		return intval(str_replace("resource id #", "", $tmp));
	}
}