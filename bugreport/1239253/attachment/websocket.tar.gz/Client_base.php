<?php
/**
 * Websocket Development File
 * 
 * @package FormsFramework
 * @subpackage common
 * @author Samuele Diella <samuele.diella@gmail.com>
 * @copyright Copyright (c) 2004-2021, Samuele Diella
 * @license https://opensource.org/licenses/LGPL-3.0
 * @link https://www.ffphp.com
 */

namespace FF\Libs\PWA\WebSocket;

abstract class Client_base
{
	const PROT_OPCODE_CONTINUATION	= 0x0;
	const PROT_OPCODE_TEXT			= 0x1;
	const PROT_OPCODE_BINARY		= 0x2;
	const PROT_OPCODE_CONN_CLOSE		= 0x8;
	const PROT_OPCODE_PING			= 0x9;
	const PROT_OPCODE_PONG			= 0xA;
	const PROT_OPCODE_RESERVED		= 0xFF; // impossible value, opcode is 4bit
	
	const PROT_OPCODE_DESCR = [
		self::PROT_OPCODE_CONTINUATION	=> "Continuation",
		self::PROT_OPCODE_TEXT			=> "Text",
		self::PROT_OPCODE_BINARY		=> "Binary",
		self::PROT_OPCODE_CONN_CLOSE		=> "Connection Close",
		self::PROT_OPCODE_PING			=> "Ping",
		self::PROT_OPCODE_PONG			=> "Pong",
		self::PROT_OPCODE_RESERVED		=> "Unknown/Reserved"
	];
	
	public $sock			= null;
	public $user_id			= null;
	public $time_connected	= null;
	public $time_lastrcv	= null;
	public $time_lastsnd	= null;
	
	protected $id = null;
	protected $ip = null;
	
	protected $last_rcv_payload = null;
	protected $headers = [];
	protected $server = null;
	
	private $handshake_done = false;
	private $buffer_read = null;
	private	$buffer_payload = null;

	private $last_opcode_type = null;
	
	private $sent_ping_data = null;
	private $sent_ping_time = null;
	
	abstract function onOpen();
	abstract function onError($code, $text);
	abstract function onClose($code, $text);
	abstract function onMessage($type, $payload);
	
	public function __construct($id, $sock, $server)
	{
		$this->id		= $id;
		$this->sock		= $sock;
		$this->server	= $server;
		
		$this->ip = stream_socket_get_name($sock, true);
	}
	
	public function getID()
	{
		return $this->id;
	}
	
	public function getIP()
	{
		return $this->ip;
	}
	
	public function getHeader($name)
	{
		if (!isset($this->headers[$name]))
			return null;
		else
			return $this->headers[$name];
	}
	
	public function isHandshakeDone()
	{
		return $this->handshake_done;
	}
	
	public function receive($raw_data, $bytes)
	{
		if ($this->handshake_done)
		{
			$rc = $this->process_frame($raw_data, $bytes);
			if ($rc === true)
				$this->onMessage($this->last_opcode_type, $this->last_rcv_payload);
		}
		else
			return $this->process_handshake($raw_data, $bytes);
	}
	
	private function process_handshake($raw_data, $bytes)
	{
		DebugOutput("Checking handshake..", 1);
		
		$raw_data = ($this->buffer_read ?? "") . $raw_data;
		
		/* check if we are dealing with a well formed content */
		if (strpos($raw_data, "\n") === false)
		{
			$this->buffer_read = $raw_data;
			DebugOutput("Rawdata incomplete, postponing", 1);
			return null;
		}
		
		$skip_last_line = substr($raw_data, -1) !== "\n";
				
		$lines = explode("\n", $raw_data);
		
		//print_r($lines);
		
		$processed_headers = [];
		$offset_data = 0;
		$line_count = -1;
		$handshake_done = false;
		
		try
		{
			for ($i = 0; $i < count($lines); $i++)
			{
				if ($skip_last_line && ($i + 1) === count($lines))
					break;
				
				$line = $lines[$i];
				$offset_data += strlen($line) + (($i + 1) < count($lines) ? 1 : 0); // add the \n character to the count for every line except the last

				if (trim($line) === "") /* headers end is marked with an empty string */
				{
					$handshake_done = true;
					break;
				}

				$line_count++;

				if ($line_count === 0)
				{
					$rc = preg_match("/([^ ]+) ([^ ]+) HTTP\/([\d\.]+)/", $line, $matches);
					if (!$rc)
						throw new \Exception("Protocol error on line #" . $i . ": Request-Line missing, found " . var_export($line, true));
					if ($matches[1] !== "GET")
						throw new \Exception("Protocol error on line #" . $i . ": Request-Line method must be GET, found " . var_export($matches[1], true));
					if (version_compare($matches[3], "1.1", "<"))
						throw new \Exception("Protocol error on line #" . $i . ": Request-Line http version must be >= 1.1, found " . $matches[3]);

					$processed_headers["Request-Line"] = [
						"method"		=> $matches[1],
						"request_uri"	=> $matches[2],
						"http_version"	=> $matches[3]
					];
				}
				else
				{
					$rc = preg_match("/([^:]+):\s*(.*)/", $line, $matches);
					if (!$rc)
						throw new \Exception("Protocol error on line #" . $i . ": Header malformed, found " . var_export($line));

					$tmp_name = trim($matches[1]);
					$tmp_value = trim($matches[2]);
					$tmp_params = explode(";", $tmp_value);
					if (count($tmp_params) === 1)
					{
						$processed_headers[$tmp_name] = $tmp_value;
					}
					else
					{
						$processed_headers[$tmp_name] = [];
						foreach ($tmp_params as $tmp_param)
						{
							$tmp_subparts = explode("=", $tmp_param);
							if (count($tmp_subparts) > 1)
							{
								$processed_headers[$tmp_name][trim($tmp_subparts[0])] = trim($tmp_subparts[1]);
							}
							else
							{
								$processed_headers[$tmp_name][trim($tmp_param)] = null;
							}
						}
					}
				}
			}
			
			if (!$handshake_done)
			{
				// postpone the processing for a next buffer reading
				$this->buffer_read = $raw_data;
				DebugOutput("Rawdata incomplete, postponing", 1);
				return null;
			}
			
			$missing_headers = array_diff(["Host", "Upgrade", "Connection", "Sec-WebSocket-Key", "Origin", "Sec-WebSocket-Version"], array_keys($processed_headers));
			if (count($missing_headers))
				throw new \Exception("Protocol error: missing headers: " . implode(", ", $missing_headers));

			if (!in_array($processed_headers["Host"], $this->server->allowed_hosts))
				throw new \Exception("Protocol error: Host " . $processed_headers["Host"] . " is not allowed");

			if (strpos($processed_headers["Upgrade"], "websocket") === false)
				throw new \Exception("Protocol error: Upgrade header does not contain the keyword websocket");

			if (strpos($processed_headers["Connection"], "Upgrade") === false)
				throw new \Exception("Protocol error: Connection header does not contain the token Upgrade");

			if (!in_array($processed_headers["Origin"], $this->server->allowed_origins))
				throw new \Exception("Protocol error: Origin " . $processed_headers["Origin"] . " is not allowed");

			if ($processed_headers["Sec-WebSocket-Version"] !== "13")
				throw new \Exception("Protocol error: WebSocket Version 13 supported, " . $processed_headers["Sec-WebSocket-Version"] . " found");
			
			/* all good, shake the hand back */
			DebugOutput("..all good, shaking back..", 1);
			
			$sec_websocket_accept = base64_encode(sha1($processed_headers["Sec-WebSocket-Key"] . "258EAFA5-E914-47DA-95CA-C5AB0DC85B11", true));

			$response = "HTTP/1.1 101 Switching Protocols\n"
						. "Upgrade: websocket\n"
						. "Connection: Upgrade\n"
						. "Sec-WebSocket-Accept: " . $sec_websocket_accept . "\n\n";
			
			stream_set_blocking($this->sock, false);
			
			$rc = @fwrite($this->sock, $response, strlen($response));
			if ($rc === false)
			{
				if (DEBUG) DebugError($this->sock, 2);
				throw new \Exception("Unable to send handshake response");
			}

			stream_set_blocking($this->sock, true);
			
			$this->handshake_done = true;
			$this->headers = $processed_headers;
			$this->buffer_read = null;
			
			DebugOutput("..handshake done", 1);
			
			$rc = $this->onOpen();
			if ($rc === false)
			{
				$this->disconnect();
				return $rc;
			}
		
			/* truncate the buffer content */
			$raw_data = substr($raw_data, $offset_data);
			if (strlen($raw_data))
			{
				DebugOutput("Some data left, processing frame", 2);
				return $this->receive($raw_data, strlen($raw_data));
			}
			
			return true;
		}
		catch (\Exception $e)
		{
			if (strlen($e->getMessage()) && DEBUG) DebugOutput($e->getMessage(), 2);
			$this->disconnect();
			return false;
		}
		finally
		{
			if ($this->sock !== null)
				@stream_set_blocking($this->sock, true);
		}
	}

	private function process_frame($raw_data, $bytes)
	{
		DebugOutput("Checking frame...", 1);
		
		$raw_data = ($this->buffer_read ?? "") . $raw_data;
		
		if ($bytes < 2)
		{
			$this->buffer_read = $raw_data;
			DebugOutput("Frame incomplete, postponing", 1);
			return null;
		}
		
		try
		{
			$byte_1	= ord($raw_data[0]);

			// get messages flags and type
			$flag_fin	= $byte_1 & 0x80 && true;
			$flag_rsv1	= $byte_1 & 0x40 && true;
			$flag_rsv2	= $byte_1 & 0x20 && true;
			$flag_rsv3	= $byte_1 & 0x10 && true;
			
			$opcode = $byte_1 & 0x0F; // only the first nibble
			$opcode_type = ($opcode >= 0x3 && $opcode <= 0x7) || ($opcode >= 0xB && $opcode <= 0xF) ? self::PROT_OPCODE_RESERVED : $opcode;

			DebugOutput("flag_fin = $flag_fin", 2);
			DebugOutput("Opcode = $opcode (" . self::PROT_OPCODE_DESCR[$opcode_type] . ")", 2);
			
			if($flag_rsv1 || $flag_rsv2 || $flag_rsv3)
			{
				//DebugOutput("ERROR: Unknown RSV<$flag_rsv1><$flag_rsv2><$flag_rsv3> flag set!", 2);
				//return null;
				throw new \Exception("ERROR: Unknown RSV<$flag_rsv1><$flag_rsv2><$flag_rsv3> flag set!");
			}

			$flag_control = $opcode & 0x8 && true;
			
			// fragmentation sanity check
			if ($flag_fin) // fragmentation bit
			{
				if (!$flag_control)
				{
					if ($opcode_type === self::PROT_OPCODE_CONTINUATION) // last fragment
					{
						if ($this->buffer_payload === null)
							throw new \Exception("ERROR: last fragment without previous ones");
					}
					else // unfragmented message
					{
						if ($this->buffer_payload !== null)
							throw new \Exception("ERROR: starting a new unfragmented message with a previous one incomplete");
					}
				}
			}
			else
			{
				if ($flag_control)
					throw new \Exception("ERROR: control frames must not be fragmented");
				
				if ($opcode_type === self::PROT_OPCODE_CONTINUATION) // subsequent fragments
				{
					if ($this->buffer_payload === null)
						throw new \Exception("ERROR: fragment continuation without previous ones");
				}
				else // first fragment
				{
					if ($this->buffer_payload !== null)
						throw new \Exception("ERROR: starting a new fragmented message with a previous one incomplete");
				}
			}

			$payload = "";

			$byte_2	= ord($raw_data[1]);
			
			// Determine mask status
			$frame_is_masked = $byte_2 & 0x80 && true;
			DebugOutput("Masked = $frame_is_masked", 2);

			// Determine payload length
			$payload_length = $byte_2 & 127; // remove the mask bit if present with a logical and on the other bits
			$lenght_offset = 0;
			if ($payload_length === 126)
			{
				if ($flag_control)
					throw new \Exception("ERROR: control frames lenght must be <= 125");
					
				if (strlen($raw_data) < 4)
				{
					$this->buffer_read = $raw_data;
					DebugOutput("Frame incomplete, postponing", 1);
					return null;
				}
				
				$payload_length = unpack("nuint16", substr($raw_data, 2, 2))["uint16"]; // network order = big endian, so "n"
				$lenght_offset = 2;
			}
			elseif ($payload_length === 127)
			{
				if ($flag_control)
					throw new \Exception("ERROR: control frames lenght must be <= 125");
					
				if (strlen($raw_data) < 10)
				{
					$this->buffer_read = $raw_data;
					DebugOutput("Frame incomplete, postponing", 1);
					return null;
				}
				
				$payload_length = unpack("Juint64", substr($raw_data, 2, 8))["uint64"];
				$lenght_offset = 8;
				
				var_dump("UINT64!");
			}

			DebugOutput("Payload Length = $payload_length", 2);

			# Getting/decoding Payload
			if ($payload_length)
			{
				if ($frame_is_masked) # Masked frame (client to server)
				{
					$mask_offset = 2 + $lenght_offset;
					$payload_offset = $mask_offset + 4;

					if (strlen($raw_data) < $payload_offset + $payload_length)
					{
						$this->buffer_read = $raw_data;
						DebugOutput("Frame incomplete, postponing [" . strlen($raw_data) . "/" . ($payload_offset + $payload_length) . "]", 1);
						return null;
					}

					# Now we extract the mask and payload
					$mask = substr($raw_data, $mask_offset, 4);
					$encoded_payload = substr($raw_data, $payload_offset);

					# Finally, we decode the encoded frame payload
					for ($i = 0; $i < $payload_length; $i++)
					{
						$payload .= $encoded_payload[$i] ^ $mask[$i % 4];
					}
				}
				else # Unmasked frame (server to client)
				{
					$payload_offset = 2 + $lenght_offset;

					if (strlen($raw_data) < $payload_offset + $payload_length)
					{
						$this->buffer_read = $raw_data;
						DebugOutput("Frame incomplete, postponing", 1);
						return null;
					}

					# Read the payload
					$payload = substr($raw_data, $payload_offset);
				}
			}
			else
			{
				$payload = "";
			}
			
			$this->buffer_read = null; // if we arrived here, we don't need it anymore, the frame is fully come
			
			if ($flag_control) // control messages should be managed indipendently from the fragment sequence
			{
				switch($opcode_type)
				{
					case self::PROT_OPCODE_CONN_CLOSE:
						$code = null;
						$status = null;
							
						if ($payload_length > 0)
						{
							$code = unpack("nuint16", substr($payload, 0, 2))["uint16"]; // network order = big endian, so "n"
							if ($payload_length > 2)
								$status = substr($payload, 2);

						}
						DebugOutput(
								"CLOSE message, disconnecting" 
								. ($code !== null ? " with code " . $code : "") 
								. ($status !== null ? ($code ? " and" : " with") . " message " . $status : "")
							, 1);
						$this->disconnect();
						return false;
						
					case self::PROT_OPCODE_PING:
						DebugOutput("PING, answering back with a pong" . ($payload_length ? " with payload: " . $payload : ""), 1);
						$this->sendPong($payload);
						return null;
					
					case self::PROT_OPCODE_PONG:
						if ($this->sent_ping_data !== null)
						{
							if ($payload !== $this->sent_ping_data)
								throw new \Exception("ERROR! PONG received with unmatched data. Sent: " . $this->sent_ping_data . " Received: " . $payload);
							DebugOutput("PONG received in answer with matching payload to ping sent at " . date("d/m/Y H:i:s.u", $this->sent_ping_time), 1);
							$this->sent_ping_data = null;
							$this->sent_ping_time = null;
						}
						else
						{
							DebugOutput("PONG received without askin for it, ignoring", 1);
						}
						return null;
					
					default:
						DebugOutput("Unknown control message type, ignoring it", 1);
						return null;
				}
			}
			else
			{
				// managing fragmentation
				if ($flag_fin) // fragmentation bit
				{
					if ($opcode_type === self::PROT_OPCODE_CONTINUATION) // last fragment
					{
						$payload = $this->buffer_payload . $payload;
						$this->buffer_payload = null;
					}
					else // unfragmented message
					{
						// nothing to do
					}
				}
				else
				{
					if ($opcode_type === self::PROT_OPCODE_CONTINUATION) // subsequent fragments
					{
						$this->buffer_payload .= $payload;
						$payload = null;
					}
					else // first fragment
					{
						$this->buffer_payload .= $payload;
						$payload = null;
					}
				}


				if ($opcode_type != self::PROT_OPCODE_CONTINUATION)
				{
					$this->last_opcode_type = $opcode_type;
				}

				if ($payload !== null)
				{
					DebugOutput("Message recevied: " . var_export($payload, true), 1);
					$this->last_rcv_payload = $payload;
					return true;
				}
				else
				{
					DebugOutput("Fragmented message incomplete, postponing", 1);
					return null;
				}
			}
		}
		catch (\Exception $e)
		{
			DebugOutput("ERROR: frame processing" . (strlen($e->getMessage()) ? " - " . $e->getMessage() : ""), 2);
			$this->onError($e->getCode(), $e->getMessage());
			$this->disconnect();
			return false;
		}
	}
	
	public function sendPong($payload)
	{
		return $this->sendMessage(self::PROT_OPCODE_PONG, false, $payload);
	}
	
	public function sendPing($payload)
	{
		if ($this->sent_ping_data === null)
		{
			$this->sent_ping_data = $payload;
			$this->sent_ping_time = time();
			return $this->sendMessage(self::PROT_OPCODE_PING, false, $payload);
		}
		else
		{
			DebugOutput("ERROR! Ping already sent, waiting for response", null);
			$this->disconnect();
			return false;
		}
	}
	
	public function sendMessage($opcode, $masked, $payload, $max_frame_size = 1000)
	{
		if ($opcode === self::PROT_OPCODE_CONTINUATION || $opcode === self::PROT_OPCODE_RESERVED)
			throw("ERROR! forbidden opcode " . self::PROT_OPCODE_DESCR[$opcode]);
			
		$payload_size = strlen($payload);
			
		// fist determine if we need fragmentation
		if ($opcode === self::PROT_OPCODE_TEXT || $opcode === self::PROT_OPCODE_TEXT)
		{
			// calculate the overhead for every message
			$header_size = 2; // [FIN + RSV1 + RSV2 + RSV3 + OPCODE(4 bit)] + [MASK + PAYLOAD LEN(7 bit)] = 16 bit
			
			if ($masked)
				$header_size += 4; // 32 bit

			if ($max_frame_size <= $header_size) // we need space for at least 1 content byte
				throw("ERROR! max_frame_size too small");
			else if ($max_frame_size > 125 && $max_frame_size <= 0xFFFF) // 16 bit unsigned int
				$header_size += 2;
			else if ($max_frame_size > 0xFFFF && $max_frame_size <= PHP_INT_MAX)  // 64 bit unsigned int
				$header_size += 8;
			else
				throw("ERROR! max_frame_size out of bounds");

			$need_fragmentation = $payload_size + $header_size > $max_frame_size;
		}
		else
		{
			$need_fragmentation = false; // fragmentation is not allowed on control frames
			if ($payload_size > 125)
				throw("ERROR! payload size limit for control frames is 125 bytes");
		}
		
		if ($need_fragmentation)
		{
			DebugOutput("TODO: fragmentation");
			return false;
		}
		else
		{
			return $this->sendFrame($opcode, $masked, $payload, true, 0, 0, 0);
		}
	}
	
	private function sendFrame($opcode, $masked, $payload, $fin, $rsv1, $rsv2, $rsv3)
	{
		try
		{
			$bytes = [];

			$byte = 0;

			if ($fin)	$byte |= 0x80;
			if ($rsv1)	$byte |= 0x40;
			if ($rsv2)	$byte |= 0x20;
			if ($rsv3)	$byte |= 0x10;

			if ($masked) $byte |= 0x08;

			$byte |= $opcode;
			$bytes[] = $byte;

			$byte = 0;

			if ($masked)	$byte |= 0x80;

			$payload_size = strlen($payload);
			if ($payload_size <= 125) // we need space for at least 1 content byte
			{
				$byte |= $payload_size;
				$bytes[] = $byte;
			}
			else if ($max_frame_size > 125 && $max_frame_size <= 0xFFFF) // 16 bit unsigned int
			{
				$byte |= 126;
				$bytes[] = $byte;

				$tmp = unpack("C*", pack("n", $i));
				array_push($bytes, ...$tmp);
			}
			else if ($max_frame_size > 0xFFFF && $max_frame_size <= PHP_INT_MAX)  // 64 bit unsigned int
			{
				$byte |= 127;
				$bytes[] = $byte;

				$tmp = unpack("C*", pack("J", $i));
				array_push($bytes, ...$tmp);
			}

			if ($masked)
			{
				$mask = pack("N", random_int(0, 0xFFFFFFFF));

				$tmp = unpack("C*", $mask);
				array_push($bytes, ...$tmp);

				for ($i = 0; $i < $payload_size; $i++)
				{
					$bytes[] = $payload[$i] ^ $mask[$i % 4];
				}
				$frame = pack("C*", ...$bytes);
			}
			else
			{
				$frame = pack("C*", ...$bytes);
				$frame .= $payload;
			}

			@stream_set_blocking($this->sock, true);

			$rc = @fwrite($this->sock, $frame, strlen($frame));
			if ($rc === false)
			{
				if (DEBUG) DebugError($this->sock, 2);
				throw new \Exception("Unable to send frame");
			}

			@stream_set_blocking($this->sock, false);
			
			return true;
		}
		catch (\Exception $e)
		{
			DebugOutput("ERROR: sending frame" . (strlen($e->getMessage()) ? " - " . $e->getMessage() : ""), 2);
			$this->onError($e->getCode(), $e->getMessage());
			return false;
		}
		finally
		{
			if ($this->sock !== null)
				@stream_set_blocking($this->sock, false);
		}
	}
	
	/*
	 * returns:
	 *  the last payload if no receive is in progress
	 *  false if a receive is in progress
	 *  null if no payload is available
	 */
	public function getRcvPayload()
	{
		if ($this->buffer_read === null)
		{
			return $this->last_rcv_payload;
		}
		else
		{
			return false;
		}
	}
	
	public function getLastRcvPayload()
	{
		return $this->last_rcv_payload;
	}
	
	public function disconnect($code = -1, $text = "NOT_SET")
	{
		if ($this->sock === null)
			return;
		
		if ($this->isHandshakeDone())
			$this->onClose($code, $text);
		
		@fclose($this->sock);
		$this->sock = null;
		
		$this->server->removeClient($this->id);
				
		DebugOutput("Client disconnected - client #" . $this->id . "[". $this->ip . "]");
	}
	
	public function __destruct()
	{
		$this->disconnect();
	}
}
