const express = require('express');
const staticServer = express();
const redirectServer = express();
const contentServer = express();

const port1 = process.env.PORT1 || 3001
const port2 = process.env.PORT2 || 3002
const port3 = process.env.PORT3 || 3003

staticServer.use(express.static(__dirname))
redirectServer.get('/', (req, res) => {
    setTimeout(() => {
        res.setHeader('Access-Control-Allow-Origin', '*')
        res.setHeader('Timing-Allow-Origin', 'https://some-random-site.com')
        res.redirect(301, `http://localhost:${port3}/`)
    }, 2500)
})

contentServer.get('/', (req, res) => {
    setTimeout(() => {
        res.setHeader('Access-Control-Allow-Origin', '*')
        res.setHeader('Timing-Allow-Origin', 'https://some-random-site.com')
        res.status(200).send('Hello World')
    }, 1000)
})

staticServer.listen(port1, () => {
    console.log(`Listening on port ${port1}`)
    redirectServer.listen(port2, () => {
        console.log(`Redirect listening on port ${port2}`)
        contentServer.listen(port3, () => {
            console.log(`Content listening on port ${port3}`)
            console.log(`Open http://localhost:${port1}/index.html?port=${port2} and wait a few seconds.`)
        })
    })
})
