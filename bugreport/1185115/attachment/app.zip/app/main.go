package main

import (
	"github.com/gin-gonic/gin"
	"math/rand"
	"net/http"
	"os"
)

var letters = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

func randSeq(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letters[rand.Intn(len(letters))]
	}
	return string(b)
}

func main() {
	// Set the router as the default one shipped with Gin
	router := gin.Default()

	router.LoadHTMLGlob("templates/*")

	// Setup route group for the API
	api := router.Group("/")
	{
		api.GET("/redirect/:RedirectID", RedirectHandler)
		api.GET("/track/", SetTrackHandler)
		api.GET("/", MainHandler)

	}
	port := os.Getenv("PORT")
	if port == "" {
		// This must  be port 5000 because EB listens on port 5000 by default.
		port = "3000"
	}


	// Start and run the server
	router.Run(":" + port)
}

func MainHandler(c *gin.Context) { // permanent 301 redirect , this will be cached.

	if cookieTracker, err := c.Cookie("cookieTracker") ; err == nil {
		c.HTML(http.StatusOK, "index.html", gin.H{
			"ID": cookieTracker,
		})
	}else{
		c.HTML(http.StatusOK, "index.html", gin.H{
			"ID": "None",
		})	}
}

func SetTrackHandler(c *gin.Context) { // permanent 301 redirect , this will be cached.
	if cookieTracker, err := c.Cookie("cookieTracker") ; err == nil {
		c.Redirect(301, "/redirect/"+cookieTracker)
	} else{
		randCookieVal := randSeq(10)
		c.Redirect(301, "/redirect/"+randCookieVal)
	}
}

func RedirectHandler(c *gin.Context) {
	if RedirectID := c.Param("RedirectID"); RedirectID != "" {
		print(RedirectID)
		c.SetCookie("cookieTracker", string(RedirectID), 65535,"/", "", false, false)
	} else{ print("nada")}

	c.Redirect(302,"/")
}