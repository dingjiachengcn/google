self.addEventListener('fetch', function(event) {
    console.log('Fetch!', event);

    return event.respondWith(fetch(event.request, {
        // Even if you manually set the credentials - it doesn't seem to matter.
        // The "samesite" cookie behaviour should take precedence over this anyway during a cross site request?
        // credentials: 'same-origin'
    }));
})