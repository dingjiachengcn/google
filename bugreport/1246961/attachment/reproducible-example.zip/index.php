<script>
navigator.serviceWorker.register('/sw.js', { scope: '/sw-echo' }).then(function(reg) {
	console.log('Service worker registered');
}).catch(function(err) {
	console.log('Failed to register service worker:', err);
});

document.cookie = 'strict=ae93de3efa544e85dcd6311732d28f95; path=/; samesite=strict; max-age=';
document.cookie = 'lax=bd4782c9f1cba8793727ef0921ae092f; path=/; samesite=lax; max-age=';
document.cookie = 'none=c9c5e752158e1dcc8480fd42b1f11277; path=/; samesite=none; max-age=';
</script>

Cookies sent are:

<pre>
    <?php print_r($_COOKIE); ?>
</pre>